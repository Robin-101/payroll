
Two system parameters are available:

* ``inactive_session_time_out_delay``: validity of a session in seconds
  (default = 2 Hours)
* ``inactive_session_time_out_ignored_url``: technical urls where the check
  does not occur
